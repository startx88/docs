---
name: Other
about: Request unrelated to a bug
title: ''
labels: ''
assignees: ''

---

<!--
*** Important Note ***
Development of Flutter for Desktop is now happening almost entirely in the Flutter repository itself. Unless your issue is related to one of the plugins in this repository, please file your issue in the Flutter issue tracker: https://github.com/flutter/flutter/issues
-->

**Describe Request**
