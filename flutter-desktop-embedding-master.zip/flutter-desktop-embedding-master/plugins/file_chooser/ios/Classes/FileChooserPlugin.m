#import "FileChooserPlugin.h"

@implementation FileChooserPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {}

@end
