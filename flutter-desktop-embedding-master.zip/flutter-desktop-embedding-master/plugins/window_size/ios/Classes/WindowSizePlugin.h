#import <Flutter/Flutter.h>

@interface WindowSizePlugin : NSObject<FlutterPlugin>
@end
