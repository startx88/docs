#import <Flutter/Flutter.h>

@interface ColorPanelPlugin : NSObject<FlutterPlugin>
@end
