#import <Flutter/Flutter.h>

@interface MenubarPlugin : NSObject<FlutterPlugin>
@end
