#import "MenubarPlugin.h"

@implementation MenubarPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {}

@end
