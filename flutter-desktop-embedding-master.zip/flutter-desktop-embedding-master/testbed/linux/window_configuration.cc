#include "window_configuration.h"

const char *kFlutterWindowTitle = "testbed";
const unsigned int kFlutterWindowWidth = 800;
const unsigned int kFlutterWindowHeight = 600;
